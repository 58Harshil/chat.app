# Chat-Bot-using-gpt-3.5-turbo
build a chatbot using the OpenAI's Chat GPT API "gpt-3.5-turbo" and Flasks Server. 

## Note: 
i used chat gpt to generate all the code.
for the front end side, you can write code as per your need to make it look different.
